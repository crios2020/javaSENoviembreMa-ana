package ar.com.eduit.curso.java.connector;
import java.sql.Connection;
import java.sql.DriverManager;
public class Connector {
    //driver mariaDB
    private String driver="org.mariadb.jdbc.Driver";
    
    //driver MySQL 5
    //private String driver="com.mysql.jdbc.Driver";
    
    //driver MySQL 6 o sup
    //private String driver="com.mysql.cj.jdbc.Driver";
    
    private String url="jdbc:mariadb://localhost:3306/colegio";
    
    private String user="root";
    
    private String pass="";
    
    private Connection conn=null;
    
    public Connection getConnection(){
        if(conn==null){
            try {
                //registrar el driver
                Class.forName(driver);
                return DriverManager.getConnection(url, user, pass);
            } catch (Exception e) {
                System.out.println("*****************************************");
                System.out.println(e);
                System.out.println("*****************************************");
                return null;
            }
        }else{
            return conn;
        }
    }
    
}