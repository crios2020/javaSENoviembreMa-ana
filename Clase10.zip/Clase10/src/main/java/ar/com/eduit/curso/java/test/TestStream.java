package ar.com.eduit.curso.java.test;

public class TestStream {
    public static void main(String[] args) {
       
    }
}