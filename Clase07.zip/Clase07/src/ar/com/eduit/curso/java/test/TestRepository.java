package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.connector.Connector;
import ar.com.eduit.curso.java.entities.Alumno;
import ar.com.eduit.curso.java.entities.Curso;
import ar.com.eduit.curso.java.enums.Dia;
import ar.com.eduit.curso.java.enums.Turno;
import ar.com.eduit.curso.java.repositories.interfaces.I_AlumnoRepository;
import ar.com.eduit.curso.java.repositories.interfaces.I_CursoRepository;
import ar.com.eduit.curso.java.repositories.jdbc.AlumnoRepository;
import ar.com.eduit.curso.java.repositories.jdbc.CursoRepository;
import java.sql.Connection;
import java.text.DecimalFormat;
import java.util.List;

public class TestRepository {
    public static void main(String[] args) {
        final Connection conn = new Connector().getConnection();
        I_CursoRepository cr=new CursoRepository(conn);
        
        Curso curso=new Curso("Jardineria","Gomez",Dia.LUNES,Turno.NOCHE);
        cr.save(curso);
        
        System.out.println(curso);
        
        //System.out.println(cr.getById(4));
        //Curso curso=cr.getById(4);
        //curso.setDia(Dia.VIERNES);
        //cr.update(curso);
        
        //cr.remove(cr.getById(5));
        
        System.out.println("*************************************************");
        List<Curso>list=cr.getAll();
        for(int a=0;a<list.size();a++){
            System.out.println(list.get(a));
        }
        
        System.out.println("*************************************************");
        I_AlumnoRepository ar=new AlumnoRepository(conn);
        
        Alumno alumno=new Alumno("Cristian","Molina",26,6);
        ar.save(alumno);
        System.out.println(alumno);
        
        System.out.println(ar.getById(5));
        
        System.out.println("*************************************************");
        List<Alumno>listAlumno=ar.getAll();
        for(int a=0;a<listAlumno.size();a++){
            System.out.println(listAlumno.get(a));
        }

        
        //String saludo="Hola, %s, Hoy es %s, día nro=%d";
        //System.out.println(String.format(saludo, "Buenos Días","Miércoles",2));
        
        //double precio=100000009.90;
        //System.out.println(precio);
        
        //DecimalFormat df=new DecimalFormat("###,###,###.00");
        //System.out.println(df.format(precio));
 
        
    }
}
