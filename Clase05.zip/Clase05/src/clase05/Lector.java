package clase05;

import java.io.Closeable;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Lector implements Closeable{
    
    private FileReader in;
    
    public Lector() throws FileNotFoundException{
        in=new FileReader(new File("texto.txt"));
    }
    
    public String leer() throws IOException{
        return (char)in.read()+"";
    }
    
    @Override
    public void close() throws IOException {
        System.out.println("Se cerro el lector!");
    }
    
}
