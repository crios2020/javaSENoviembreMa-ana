package clase05;

public class NoHayMasPasajesException extends Exception{
    private String nombreVuelo;
    private int cantidadPasajesVuelo;
    private int cantidadPasajesPedidos;

    public NoHayMasPasajesException(String nombreVuelo, int cantidadPasajesVuelo, int cantidadPasajesPedidos) {
        this.nombreVuelo = nombreVuelo;
        this.cantidadPasajesVuelo = cantidadPasajesVuelo;
        this.cantidadPasajesPedidos = cantidadPasajesPedidos;
    }

    @Override
    public String toString() {
        return "El vuelo " + nombreVuelo + ", no tiene " + cantidadPasajesPedidos 
                + " pasajes, solo hay " + cantidadPasajesVuelo + " pasajes disponibles.";
    }

    public String getNombreVuelo() {
        return nombreVuelo;
    }

    public int getCantidadPasajesVuelo() {
        return cantidadPasajesVuelo;
    }

    public int getCantidadPasajesPedidos() {
        return cantidadPasajesPedidos;
    }
    
    
}
