package clase05;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Clase05 {
    public static void main(String[] args) {
        // Clase 05 Manejo de Excpetions
        
        //System.out.println(10/0);
        //System.out.println("Esta linea no se ejecuta!");
        
        /*
        Estructura try - catch - finally
        
        try{                                        //Obligatorio
            - Colocar todas las sentencias que pueden lanzar Exception.
            - Estas sentencias tiene más costo de hardware.
            - Si no se produce Exception, el bloque try termina normalmente.
            - Si hay una Exception este bloque interrupe el control y salta el control
                al bloque catch.
        } catch (Exception e) {                     //Obligatorio
            - Estas sentencias se ejecutan cuando ocurrio una Exception en bloque try.
            - Se recibe como parametro un Objeto de la clase Exception.
        } finally {                                 //Opcional
            - Este bloque se ejecuta siempre.
            - Las variables declaradas en Try o catch estan fuera de scope
        }
        
        - El termina normalmente.
        */
        
        try{
            System.out.println(10/0);
            System.out.println("Esta linea no se ejecuta!");
        }catch(Exception e){
            System.out.println("Ocurrio un error!");
            System.out.println(e);
        }finally{
            System.out.println("El programa termina normalmente");
        }
        
        System.out.println("*************************************************");
        
        try {
            //GeneradorDeExceptions.generar();
            //GeneradorDeExceptions.generar(true);
            //GeneradorDeExceptions.generar("26v");
            //GeneradorDeExceptions.generar(null, 10);
            //FileReader in=new FileReader(new File("texto.txt"));
        } catch (Exception x) {
            System.out.println(x);
        }
        
        System.out.println("*************************************************");
        
        //Captura personalizada de Exceptions
        try {
            //GeneradorDeExceptions.generar();
            FileReader in=new FileReader(new File("texto.txt"));
        } catch (IndexOutOfBoundsException e)       { System.out.println("Indice fuera de rango!");
        //} catch (ArrayIndexOutOfBoundsException | StringIndexOutOfBoundsException e) 
        //                                            { System.out.println("Indice fuera de rango!");
        } catch (ArithmeticException e)             { System.out.println("División por cero");   
        } catch (NumberFormatException e)           { System.out.println("Formato de numero incorrecto");
        } catch (NullPointerException e)            { System.out.println("Puntero Nulo!");
        //} catch (StringIndexOutOfBoundsException e) { System.out.println("Indice fuera de rango!");
        } catch (FileNotFoundException e)           { System.out.println("Archivo no encontrado!");
        } catch (IOException e)                     { System.out.println("Error IO");
        } catch (Exception e)                       { System.out.println("Ocurrio un error no esperado!");
        }
     
        System.out.println("*************************************************");
        // Manejo de Exceptions para validar reglas de negocio
        Vuelo v1=new Vuelo("aer1234",100);
        Vuelo v2=new Vuelo("lan1111",100);
        
        try{
            v1.venderPasajes(20);
            v2.venderPasajes(30);
            v1.venderPasajes(60);
            v2.venderPasajes(10);
            v1.venderPasajes(50);           //Lanza una Exception 
            v2.venderPasajes(10);           //No se ejecuta.
        }catch(NoHayMasPasajesException e){
            System.out.println(e);
        }
        
        //Try with resources        JDK7
        try (Lector lector=new Lector()){
            System.out.println(lector.leer());
            throw new Exception();
            //lector.close();
        } catch (Exception e) {
            System.out.println(e);
        }
        
    }
    
}
