package clase08;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class Clase08 {

    public static void main(String[] args) {
            //Clase 08 Collections
            
            //int x=0;
            //System.out.println(x);
            
            int[] numeros=new int[5];
            //for(int a=0;a<numeros.length;a++) System.out.println(numeros[0]);
            //for(int n:numeros) System.out.println(n);
            
            Auto[] autos=new Auto[4];
            autos[0]=new Auto("Fiat","Uno","Blanco");
            autos[1]=new Auto("Ford","Ka","Negro");
            autos[2]=new Auto("Peugeot","3008","Gris");
            autos[3]=new Auto("VW","Gol","Rojo");
            
            //Recorrido por indices
            //for(int a=0;a<autos.length;a++) System.out.println(autos[a]);
            
            //Recorrido forEach JDK 5 o sup.
            for(Auto a:autos) System.out.println(a);
            
            //Interface List
            // Representa una lista tipo vector dinamica con indices
            List lista;             //lista tipo Object
            lista=new ArrayList();
            //lista=new LinkedList();
            
            lista.add(new Auto("Citroen","C4","Bordo"));
            lista.add(new Auto("Renault","Kangoo","Amarillo"));
            lista.add(0, new Auto("Ford","Ka","Azul"));
            //lista.remove(0);
            lista.add("hola");
            lista.add(22);
            
            //copiar autos del vector autos a lista
            for(Auto a:autos) lista.add(a);
            
            System.out.println("*********************************************");
            //Recorrido con indices
            //for(int a=0;a<lista.size();a++) System.out.println(lista.get(a));
            
            //Recorrido forEach
            //for(Object o:lista) System.out.println(o);
            
            //Recorrido con método .forEach()   JDK 8 o sup.
            //lista.forEach(o->System.out.println(o));
            lista.forEach(System.out::println);
            
            //Uso de Generics <> jdk o 5 sup.
            List<Auto>lista2=new ArrayList();
            lista2.add(new Auto("Fiat","Qubo","Blanco"));
            
            Auto auto1=(Auto)lista.get(0);
            Auto auto2=lista2.get(0);
            
            //copiar autos de lista a lista2
            lista.forEach(o->{if(o instanceof Auto) lista2.add((Auto)o);});
            
            System.out.println("*********************************************");
            lista2.forEach(System.out::println);
            
            //Interface Set
            // Representa una lista sin indices y sin valores duplicados
            Set<String> set;
            
            //Implementación HashSet:   Es la más veloz, pero es desorganizada.
            //set=new HashSet();
            
            //Implementación LinkedHashSet: Usa una lista enlazada, almacena elementos por orden de ingreso.
            //set=new LinkedHashSet();
            
            //Implementación TreeSet: Usa un arbol balanceado, almacena elementos por orden natural.
            set=new TreeSet();
            
            set.add("Lunes");
            set.add("Martes");
            set.add("Miércoles");
            set.add("Jueves");
            set.add("Viernes");
            set.add("Sábado");
            set.add("Domingo");
            set.add("Lunes");
            set.add("Lunes");
            set.add("Lunes");
            System.out.println("*********************************************");
            set.forEach(System.out::println);
            
            Set<Auto>setAutos;
            
            //setAutos=new LinkedHashSet();
            setAutos=new TreeSet();
            
            //copiar los autos de lista2 a setAutos
            setAutos.addAll(lista2);
            setAutos.add(new Auto("VW","Gol","Rojo"));
            
            System.out.println("*********************************************");
            setAutos.forEach(a->System.out.println(a+" "+a.hashCode()));
            
            //Comparable de Alumnos con edad
            
            //Pilas Colas
            
            // Interface Map
            
            
            
            
    }
    
}
