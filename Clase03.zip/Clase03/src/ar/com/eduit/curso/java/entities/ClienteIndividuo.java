package ar.com.eduit.curso.java.entities;

public class ClienteIndividuo {
    private int nro;
    private String nombre;
    private Cuenta cuenta;

    public ClienteIndividuo(int nro, String nombre) {
        this.nro = nro;
        this.nombre = nombre;
    }

    public ClienteIndividuo(int nro, String nombre, Cuenta cuenta) {
        this.nro = nro;
        this.nombre = nombre;
        this.cuenta = cuenta;
    }

    @Override
    public String toString() {
        return "ClienteIndividuo{" + "nro=" + nro + ", nombre=" + nombre + ", cuenta=" + cuenta + '}';
    }

    public int getNro() {
        return nro;
    }

    public String getNombre() {
        return nombre;
    }

    public Cuenta getCuenta() {
        return cuenta;
    }

    public void setCuenta(Cuenta cuenta) {
        this.cuenta = cuenta;
    }
  
}
