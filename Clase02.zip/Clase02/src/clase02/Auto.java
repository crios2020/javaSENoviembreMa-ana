package clase02;

//declaración de clase.
public class Auto {
    // Las clases en java son objetos de la java.lang.Class
    
    //atributos
    // Los atributos en java son objetos de la clase java.lang.reflect.Field
    // Los atributos son variables contenidas dentro de la clase.
    // Los atributos tienen un proceso de inicialización automatico.
    // Los atributos numericos se inicializan automaticamente en 0.
    // Los atributos String se inicializan en null.
    String marca;
    String modelo;
    String color;
    int velocidad;
    
    //métodos constructores
    
    /**
     * Este método esta deprecado por Carlos Ríos el 13/11/2020 por resultar 
     * inseguro, usar en su reemplazo Auto(String marca, String modelo, String color)
     * @deprecated
     */
    @Deprecated
    Auto(){} //constructor vacio

    Auto(String marca, String modelo, String color) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
    }

    //métodos
    // Los métodos en java son objetos de la clase java.lang.reflect.Method
    void acelerar(){                                                        //acelerar
        velocidad+=10;          //velocidad=velocidad+10;
        if(velocidad>100) velocidad=100;
    }
    
    //métodos sobrecargados
    void acelerar(int kilometros){                                          //acelerarInt
        //parametro de entrada
        velocidad+=kilometros;
    }
    
    void acelerar(int t,int x){                                             //acelerarIntInt
        
    }
    
    void frenar(){
        velocidad-=10;          //velocidad=velocidad-10;
    }
    
    void imprimirVelocidad(){
        System.out.println(velocidad);
    }
    
    //método con devolución de valor
    int getVelocidad(){
        return velocidad;
    }
    
    String getMarca(){
        return marca;
    }
   
    @Override
    public String toString(){
        return marca+", "+modelo+", "+color+", "+velocidad;
    }
    
}//end class

//se pueden crear otros miembros en un archivo (No recomendado)
//un Archivo .java solo puede tener un miembro publico
class Moto{}
class Bicicleta{}
interface Vehiculo{}
interface Clase{}
enum Semana{ LUNES, MARTES, MIERCOLES, JUEVES, VIERNES }
enum Estaciones{ PRIMAVERA,VERANO,OTOÑO, INVIERNO }

//Identificadores validos (clases,variables,atributos,métodos,constantes)
class _Hola{}
class $Hola{}
// class %Hola{} //Error no se permite %/() - * +

class Hola_2{}
// class 2_Hola{} //Error 


