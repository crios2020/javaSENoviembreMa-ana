package clase02;

import javax.swing.JOptionPane;

public class Clase02 {
    static int nro;
    public static void main(String[] args) {
        // Clase 02 Programación Orientada a Objetos
        
        //Clases que tiene método main(String[] args) son clases que se pueden ejecutar
        //El vector String[] args, representa los argumentos que ingresan por consola.
        
        
        System.out.println("-- auto1 --");
        Auto auto1=new Auto();  //new Auto() invoca el constructor de la clase Auto.
        auto1.marca="Ford";
        auto1.modelo="Ka";
        auto1.color="Negro";
        
        auto1.acelerar();       //10
        auto1.acelerar();       //20
        auto1.acelerar();       //30
        auto1.frenar();         //20
        auto1.acelerar(12);     //32
        
        
        System.out.println(auto1.marca+" "+auto1.modelo+" "+auto1.color+" "+auto1.velocidad);
        
        System.out.println("-- auto2 --");
        Auto auto2=new Auto();
        auto2.marca="Fiat";
        auto2.modelo="Idea";
        auto2.color="Gris";
        
        for(int a=0;a<=65;a++) auto2.acelerar();
        
        System.out.println(auto2.marca+" "+auto2.modelo+" "+auto2.color+" "+auto2.velocidad);
        
        
        //Las variables deben ser inicializadas
        //int x=0;
        //String texto=null;
        //System.out.println(x);
        //System.out.println(texto);
        //System.out.println(nro);
        
        
        System.out.println("-- auto3 --");
        Auto auto3=new Auto("WV","Gol","Blanco");
        auto3.acelerar(35);
        
        auto3.imprimirVelocidad();
        
        System.out.println(auto3.getVelocidad());
        
        //JOptionPane.showMessageDialog(null, "Hola a todos!");
        //JOptionPane.showMessageDialog(null, "Velocidad: "+auto3.getVelocidad());
        
        //toString()
        System.out.println(auto3.toString());
        System.out.println(auto3);
        
        
        
        
    }
    
}
