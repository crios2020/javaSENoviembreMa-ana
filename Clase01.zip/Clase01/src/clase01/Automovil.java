package clase01;

/**
 * Clase que representa vehiculos de calle
 * @author carlos
 */
public class Automovil {
    String marca;
    String modelo;
    String color;
    int velocidad;
    
    /**
     * Este método acelera la velocidad del automovil en 10 kilometros hora.
     * El limite máximo de velocidad es 100 kilometros hora.
     */
    void acelerar(){
        velocidad+=10;
        if(velocidad>100) velocidad=100;
    }
    
    /**
     * Este método acelera la velocidad del automovil sengun el valor del parametro.
     * El limite máximo de velocidad es 100 kilometros hora.
     * @param kilometros cantidad de kilometros a acelerar el Automovil.
     */
    void acelerar(int kilometros){
        //velocidad+=kilometros;
        velocidad=velocidad+kilometros;
        if(velocidad>100) velocidad=100;
    }
}
