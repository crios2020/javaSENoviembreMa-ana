package clase01;

import java.math.BigDecimal;

/**
 * Clase principal del proyecto, de la clase 1 del curso java SE
 * @author carlos
 */
public class Clase01 {
    /**
     * Punto de entrada del proyecto.
     * @param args argumentos que ingresan desde consola.
     */
    public static void main(String[] args) {
        /*
        Curso: Java Standard Web Programming JSE 8.X
        Días: Miércoles Viernes 10:00 a 13:00 hs.
        Profe: Carlos Ríos      carlos.rios@educacionit.com 
        
        Materiales:     alumni.educacionit.com  
        user: email     pass: dni
        
        https://github.com/crios2020/javaSENoviembreMa-ana
        
        Software:   JDK 8.X o 11.X
        
        JDK: Java Development Kit
        
        LTS: Long Term Support      8 años
        
        Versión             Liberado                Fin Soporte
        JDK 8 LTS           Marzo 2014              Marzo 2022
        JDK 9               Octubre 2017            Marzo 2018
        JDK 10              Marzo   2018            Septiembre 2018
        JDK 11 LTS          Octubre 2018            Octubre 2026
        JDK 12              Marzo 2019              Octubre 2019
        JDK 13              Octubre 2019            Marzo 2020
        JDK 14              Marzo 2020              Octubre 2020
        JDK 15              Octubre 2020            Marzo 2021
        JDK 16              Marzo 2021              Octubre 2021
        JDK 17 LTS          Octubre 2021            Octurbre 2029    
        
        
        IDEs: (Integrated Development Enviroment)
                Netbeans, IntelliJ, Eclipse, STS Spring Tools Suite
        
        */
        
        // Linea de comentarios
        
        /* Bloque de comentarios */
        
        /**
         * Bloque de comentarios JavaDOC
         * Este comentario, debe colocarse delante de una declaración de clase o
         * declaración de método.
         * Este comentario, es visible desde afuera del archivo binario o ejecutable.
         */
        
        Automovil auto=new Automovil();
        auto.acelerar(12);
        
        // sout TAB
        System.out.println("Hola Mundo!!");
        
        //tipo de datos primitivo
       
        //Tipo de datos entero
        
        // boolean                  1 byte
        boolean bo=true;
        System.out.println(bo);
        bo=false;
        System.out.println(bo);
        
        // byte                     1 byte
        byte by=100;
        System.out.println(by);
        by=-120;
        System.out.println(by);
        
        // short                    2 bytes
        short sh=20000;
        System.out.println(sh);
        
        // int                      4 bytes
        int in=2000000000;
        System.out.println(in);
        
        // long                     8 bytes
        long lo=3000000000L;
        System.out.println(lo);
        
        // char                     2 bytes unsigned
        char ch=65;
        ch+=32;
        System.out.println(ch);
        ch='b';
        ch-=32;
        System.out.println(ch);
        
        // Punto flotante
        // Tipo de datos float 32 bits
        float fl=4.55f;
        System.out.println(fl);
        
        // Tipo de datos double 64 bits
        double dl=4.55;
        System.out.println(dl);
        
        fl=1;
        System.out.println(fl/3);
        fl=10;
        System.out.println(fl/3);
        fl=100;
        System.out.println(fl/3);
        fl=-100;
        System.out.println(fl/3);
        
        dl=10;
        System.out.println(dl/3);
        dl=100;
        System.out.println(dl/3);
        
        // Clase String 
        String texto="Esta es una cadena de caracteres!";
        System.out.println(texto);
        
        // recorrido de string texto
        for(int a=0;a<texto.length();a++){
            System.out.print(texto.charAt(a));
        }
        System.out.println();
        
        // tipo de datos var JDK 9 o superior
        var var1=20;                //int
        var1=30;
        // var1=4.55;   //error
        var var2=true;              //boolean
        var var3="hola";            //String
        var var4='F';               //char
        var var5=3000L;             //long
        var var6=34.44;             //double
        var var7=34.44d;            //double
        var var8=34.44f;            //float
        
        
        metodo(true);
        
        //imprimir en mayuscula la variable texto
        System.out.println(texto);
        
        for(int a=0;a<texto.length();a++){
            char car=texto.charAt(a);
            if(car>=97 && car<=122) car-=32;
            System.out.print(car);
        }
        System.out.println();
        
        System.out.println(texto.toUpperCase());
        System.out.println(texto.toLowerCase());
        
    }
    
    public static void metodo(int nro){
        System.out.println("1");
    }
    public static void metodo(float nro){
        System.out.println("2");
    }
    public static void metodo(double nro){
        System.out.println("3");
    }
    public static void metodo(long nro){
        System.out.println("4");
    }
    public static void metodo(Object x){
        System.out.println("5");
    }
    
    
}
