package clase03;

public class Clase03 {

    public static void main(String[] args) {
        // Clase 03
        
        /*
                Modificadores de visibilidad para miembros de clase (atributos y métodos)
        
        Modificador         Alcance
        default(omitido)    Solo es visible desde la misma clase o clases del mismo paquete.
        public              Es visible desde la misma clase y desde clases de cualquier paquete.
        private             Solo es visible desde la misma clase.
        protected           Es visible desde la misma clase, desde clases hijas y desde clases
                            del mismo paquete.
        
        */
        
    }
    
}
