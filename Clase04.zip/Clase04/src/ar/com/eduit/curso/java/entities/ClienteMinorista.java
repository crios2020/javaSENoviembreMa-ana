package ar.com.eduit.curso.java.entities;

public class ClienteMinorista {
    private int nro;
    private String nombre;
    private Cuenta cuenta;

    public ClienteMinorista(int nro, String nombre,int nroCuenta) {
        this.nro = nro;
        this.nombre = nombre;
        this.cuenta = new Cuenta(nroCuenta, "arg$");
    }
    
    //public void resetCuenta(int nroCuenta){
    //    this.cuenta=new Cuenta(nroCuenta,"arg$");
    //}

    @Override
    public String toString() {
        return "ClienteMinorista{" + "nro=" + nro + ", nombre=" + nombre + ", cuenta=" + cuenta + '}';
    }

    public int getNro() {
        return nro;
    }

    public String getNombre() {
        return nombre;
    }

    public Cuenta getCuenta() {
        return cuenta;
    }
    
}
