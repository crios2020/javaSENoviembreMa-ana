package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.entities.ClienteIndividuo;
import ar.com.eduit.curso.java.entities.ClienteMayorista;
import ar.com.eduit.curso.java.entities.ClienteMinorista;
import ar.com.eduit.curso.java.entities.Cuenta;
import java.util.ArrayList;

public class TestRelaciones {
    public static void main(String[] args) {
        
        //Objetos MOCKs (Objetos Simulados)
        
        System.out.println("-- cuenta1 --");
        Cuenta cuenta1=new Cuenta(1, "arg$");
        cuenta1.depositar(60000);
        cuenta1.depositar(30000);
        cuenta1.debitar(6000);
        System.out.println(cuenta1);
        
        System.out.println("-- clienteMinorista1 --");
        ClienteMinorista clienteMinorista1=new ClienteMinorista(1, "Juan Perez", 2);
        clienteMinorista1.getCuenta().depositar(80000);
        clienteMinorista1.getCuenta().debitar(20000);
        
        Cuenta cuentaCM1=clienteMinorista1.getCuenta();
        cuentaCM1.depositar(30000);
        
        System.out.println(clienteMinorista1);
        
        
        System.out.println("-- clienteIndividuo1 --");
        ClienteIndividuo clienteIndividuo1=new ClienteIndividuo(1, "Ana Belen", new Cuenta(3,"arg$"));
        clienteIndividuo1.getCuenta().depositar(130000);
        
        System.out.println("-- clienteConjugue --");
        ClienteIndividuo clienteConjugue=new ClienteIndividuo(2,"Silvio Gabriel",clienteIndividuo1.getCuenta());
        clienteConjugue.getCuenta().debitar(20000);
        
        System.out.println(clienteIndividuo1);
        System.out.println(clienteConjugue);
        
        System.out.println("-- clienteMayorista1 --");
        ClienteMayorista clienteMayorista1=new ClienteMayorista(1,"Todo Limpio SRL");
        ArrayList<Cuenta> lista=clienteMayorista1.getCuentas();
        lista.add(new Cuenta(10,"arg$"));           //0
        lista.add(new Cuenta(11,"Reales"));         //1
        lista.add(new Cuenta(12,"U$S"));            //2
        
        lista.get(0).depositar(50000);
        lista.get(0).depositar(140000);
        lista.get(0).debitar(12000);
        lista.get(1).depositar(60000);
        lista.get(2).depositar(16000);
        
        System.out.println(clienteMayorista1);
        for(int a=0;a<lista.size();a++) System.out.println(lista.get(a));
        
        
        
        
    }
}
