package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.entities.Cliente;
import ar.com.eduit.curso.java.entities.Cuenta;
import ar.com.eduit.curso.java.entities.Direccion;
import ar.com.eduit.curso.java.entities.Empleado;
import ar.com.eduit.curso.java.entities.Persona;

public class TestHerencia {
    public static void main(String[] args) {
        //Clase 04 Herencia
        
        System.out.println("-- dir1 --");
        Direccion dir1=new Direccion("medrano av.".toUpperCase(), 162, "1", "1");
        System.out.println(dir1);
        
        System.out.println("-- dir2 --");
        Direccion dir2=new Direccion("Lavalle",386,null,null,"Ituzaingo");
        System.out.println(dir2);
        
        /*
        System.out.println("-- persona1 --");
        Persona persona1=new Persona("Juan", "Perez", 30, new Direccion("Lima",233,"2","a"));
        persona1.saludar();
        System.out.println(persona1);
        
        System.out.println("-- persona2 --");
        Persona persona2=new Persona("Ana","Lozano",32, persona1.getDireccion());
        persona2.saludar();
        System.out.println(persona2);
        
        System.out.println("-- persona3 --");
        Persona persona3=new Persona("Lautaro", "Rodrigues", 20, dir2);
        persona3.saludar();
        System.out.println(persona3);
        */
        
        System.out.println("-- empleado1 --");
        Empleado empleado1=new Empleado(1, 120000, "Ana", "Suarez", 23, dir1);
        empleado1.saludar();
        System.out.println(empleado1);
        
        int edad=47;
        String nombre="Carlos";
        String apellido="Ríos";
        
        saludar(nombre, apellido, edad);
        
        System.out.println("-- cliente1 --");
        Cliente cliente1=new Cliente(1,new Cuenta(1,"arg$"),"Maria","Salinas",37,dir2);
        cliente1.saludar();
        cliente1.getCuenta().depositar(30000);
        System.out.println(cliente1);
        
        //Polimorfismo
        Persona p1 = new Empleado(2,400000,"Diego","Leon",34,dir1);
        Persona p2 = new Cliente(2,cliente1.getCuenta(),"Marisa","Vazques",38,dir2);
        
        p1.saludar();
        p2.saludar();
        
        Empleado e1=(Empleado)p1;           //casteo
        
        Empleado e2=(p1 instanceof Empleado)?(Empleado)p1:null;
        
        //Empleado e2=null;
        
        if(p1 instanceof Empleado){
            e2=(Empleado)p1;
        }
        
        
    }
    
    public static void saludar(String nombre, String apellido, int edad){
        System.out.println("hola "+nombre+" "+apellido+" "+edad+" años.");
    }
    
    
}