package ar.com.eduit.curso.java.entities;

public class Cliente extends Persona {
    private int nroLegajo;
    private Cuenta cuenta;

    public Cliente(int nroLegajo, Cuenta cuenta, String nombre, String apellido, int edad, Direccion direccion) {
        super(nombre, apellido, edad, direccion);
        this.nroLegajo = nroLegajo;
        this.cuenta = cuenta;
    }

    @Override
    public void saludar() {
        System.out.println("Hola soy un cliente!");
    }

    @Override
    public String toString() {
        return super.toString()+" Cliente{" + "nroLegajo=" + nroLegajo + ", cuenta=" + cuenta + '}';
    }

    public int getNroLegajo() {
        return nroLegajo;
    }

    public void setNroLegajo(int nroLegajo) {
        this.nroLegajo = nroLegajo;
    }

    public Cuenta getCuenta() {
        return cuenta;
    }

    public void setCuenta(Cuenta cuenta) {
        this.cuenta = cuenta;
    }

}
