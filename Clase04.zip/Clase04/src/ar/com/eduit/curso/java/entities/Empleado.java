package ar.com.eduit.curso.java.entities;
public class Empleado extends Persona{
    private int nroLegajo;
    private float sueldoBasico;

    public Empleado(int nroLegajo, float sueldoBasico, String nombre, String apellido, int edad, Direccion direccion) {
        super(nombre, apellido, edad, direccion); //llama al constructor de clase padre
        this.nroLegajo = nroLegajo;
        this.sueldoBasico = sueldoBasico;
    }

    @Override
    public void saludar() {
        System.out.println("Hola Soy un Empleado!");
    }

    @Override
    public String toString() {
        return super.toString()+" Empleado{" + "nroLegajo=" + nroLegajo + ", sueldoBasico=" + sueldoBasico + '}';
    }

    public int getNroLegajo() {
        return nroLegajo;
    }

    public void setNroLegajo(int nroLegajo) {
        this.nroLegajo = nroLegajo;
    }

    public float getSueldoBasico() {
        return sueldoBasico;
    }

    public void setSueldoBasico(float sueldoBasico) {
        this.sueldoBasico = sueldoBasico;
    }

}