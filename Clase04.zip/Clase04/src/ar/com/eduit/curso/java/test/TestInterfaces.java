package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.interfaces.FileCloud;
import ar.com.eduit.curso.java.interfaces.FileText;
import ar.com.eduit.curso.java.interfaces.I_File;

public class TestInterfaces {
    public static void main(String[] args) {
        I_File file=null;
        
        file=new FileText();
        //file=new FileCloud();
        
        
        //app
        file.setText("Hola");
        System.out.println(file.getText());
        file.info();
        
    }
}
