package ar.com.eduit.curso.java.entities;

import java.util.ArrayList;

public class ClienteMayorista {
    private int nro;
    private String razonSocial;
    private ArrayList<Cuenta> cuentas=new ArrayList();

    public ClienteMayorista(int nro, String razonSocial) {
        this.nro = nro;
        this.razonSocial = razonSocial;
    }
    
    //public void addCuenta(Cuenta cuenta){
    //    cuentas.add(cuenta);
    //}
    
    public void addCuenta(int nroCuenta,String moneda){
        cuentas.add(new Cuenta(nroCuenta,moneda));
    }

    @Override
    public String toString() {
        return "ClienteMayorista{" + "nro=" + nro + ", razonSocial=" + razonSocial + ", cuentas=" + cuentas + '}';
    }

    public int getNro() {
        return nro;
    }

    public String getRazonSocial() {
        return razonSocial;
    }

    public ArrayList<Cuenta> getCuentas() {
        return cuentas;
    }
    
    
}