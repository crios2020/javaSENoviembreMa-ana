package ar.com.eduit.curso.java.interfaces;
public interface I_File {
    /*
    - Una interface solo tiene miembros publicos.
    - Una interface no tiene constructores ni atributos de instancia
    - Una interface puede tener métodos abstractos.
    - Una interface puede tener atributos constantes 'final' o atributos static
    - Una clase puede implementar muchas interfaces.
    */
    
    /**
     * JavaDoc es heredada
     * @param text 
     */
    void setText(String text);
    String getText();
    
    //método default - JDK 8
    default void info(){
        System.out.println("Interface I_File");
    }
    
}